#include "test-glib.h"

GList *test_glist_echo (GList *list)
{
  return list;
}
